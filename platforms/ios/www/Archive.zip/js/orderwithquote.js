/**
 * Created by ash on 5/1/17.
 */

class OrderWithQuote {

    SearchQuoteNo(){
        console.log("Ordering with quote");
    }


}
