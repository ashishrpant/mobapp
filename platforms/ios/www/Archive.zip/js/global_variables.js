  /*
  * This file consists of all global variables which will be used on the system.
  * @param {string} serial_number ; holds the serial_number user makes search on.
  * @param {string} password ; hold the password posted from the form.
  */

  var serial_number;
  var url = 'https://rfcoax.com/mobile-application/';
  var form_attribute;
  var incoming_data;
  //var localurl = 'https://rfcoax.com/mobile-application/api-calls/';

  var localurl = 'api-calls/';


  var api_urls = 'https://rfcoax.com/mobile-application/api-';