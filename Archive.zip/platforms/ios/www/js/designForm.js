/**
 * Created by ash on 4/11/17.
 */

class DesignForm {

    LoadFormListSubmitDiam(diameterType){
        console.log(diameterType);
    }

}